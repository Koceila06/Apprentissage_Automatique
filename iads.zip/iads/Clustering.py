from scipy.spatial import distance
import pandas as pd
import numpy as np
def normalisation(DF):
    data_frame=pd.DataFrame()
    for col in DF.columns :
        mini= min(DF[col])
        maxi=max(DF[col])
        data_frame[col]= (DF[col]-mini) / (maxi-mini)
    return data_frame

def dist_euclidienne(v1,v2):
    return distance.euclidean(v1,v2)
    
def dist_manhattan(v1,v2):
    dis=0
    for i in range(len(v1)):
        dis+=abs(v1[i] - v2[i])
    return dis

def dist_vect(v1, v2):
    return dist_euclidienne(v1, v2)

def centroide(DF):
    return DF.mean(axis=0)

def dist_centroides(v1,v2):
    return distance.euclidean(centroide(v1),centroide(v2))

def initialise(DF):
    dic=dict()
    for ex in range(len(DF)):
        dic[ex]=[ex]
    return dic

def fusionne(data, partition, verbose=False, dist_type='euclidienne', linkage="centroide"):
    """
    Fusionne les 2 clusters les plus proches
    :param data: DataFrame étudié
    :param partition: Partition des clusters jusqu'à lors
    :param verbose:
    :param dist_type: Type de distance à calculer ('euclidienne' ou 'manhattan')
    :return: tuple(Partition1, int, int, distance(entre les 2 clusters fusionnés))
    """

    indice_i = -1
    indice_j = -1
    dist = 2

    for i in partition.keys():
        for j in partition.keys():
            if linkage == "centroide"  and (i != j):
                if dist_vect(centroide(data.iloc[partition[i]]), centroide(data.iloc[partition[j]])) < dist:
                    indice_j = j
                    indice_i = i
                    dist = dist_vect(centroide(data.iloc[partition[i]]), centroide(data.iloc[partition[j]]))
            elif linkage == "complete"and (i != j):
                dista_b = -1
                for a in partition[i]:
                    for b in partition[j]:
                        if dist_vect((data.iloc[a]), (data.iloc[b])) > dista_b :
                            dista_b = dist_vect( (data.iloc[a]), (data.iloc[b]))

                if dista_b < dist:
                    indice_j = j
                    indice_i = i
                    dist = dista_b
            elif linkage == "simplee"and (i != j):
                dista_b = 2
                for a in partition[i]:
                    for b in partition[j]:
                        if dist_vect( (data.iloc[a]), (data.iloc[b])) < dista_b :
                            dista_b = dist_vect( (data.iloc[a]), (data.iloc[b]))

                if dista_b < dist:
                    indice_j = j
                    indice_i = i
                    dist = dista_b
    suiv = list(partition.keys())[-1] +1

    part = partition.copy()
    part.pop(indice_i)
    part.pop(indice_j)

    if verbose:
        print("Distance minimale trouvée entre", [indice_i, indice_j], " = ", dist)

    # part[suiv] = [partition[indice_i], partition[indice_j]]
    tmp = []
    tmp.extend(partition[indice_i])
    tmp.extend(partition[indice_j])
    part[suiv] = tmp
    return part, indice_i, indice_j, dist

import scipy.cluster.hierarchy
def inertie_cluster(Ens):
    centroid =centroide(Ens)
    Ens = np.asarray(Ens)
    inertie = 0
    for i in range(len(Ens)):
        inertie += dist_vect(Ens[i], centroid)**2

    return inertie
    
############# A COMPLETER 
def clustering_hierarchique(data, verbose=False, dendrogramme=False, linkage="centroide"):
    """
    Revoie une liste de listes contenant les 2 indices d'éléments fusionnés, la distance les séparant et la somme du nombre d'éléments des 2 éléments fusionnés
    :param data: Dataframe
    :return:
    """
    part = initialise(data)
    res = []
    while len(part.keys()) >= 2:
        part, k1, k2, dist = fusionne(data, part, verbose=verbose, linkage=linkage)
        tmp = [k1, k2, dist, len(part[list(part.keys())[-1]])]
        res.append(tmp)

    if dendrogramme:
        # Paramètre de la fenêtre d'affichage:
        plt.figure(figsize=(30, 15)) # taille : largeur x hauteur
        plt.title('Dendrogramme', fontsize=25)
        plt.xlabel("Indice d'exemple", fontsize=25)
        plt.ylabel('Distance', fontsize=25)

        # Construction du dendrogramme pour notre clustering :
        scipy.cluster.hierarchy.dendrogram(
            res,
            leaf_font_size=24.,  # taille des caractères de l'axe des X
        )

        # Affichage du résultat obtenu:
        plt.show()


    return res
import random 
def init_kmeans(K,Ens):
    Ens = np.asarray(Ens)
    return Ens[np.random.choice(Ens.shape[0], K, replace=False), :]

def plus_proche(Exe,Centres):
    mini=999999999
    index=-1
    for c in range(len(Centres)) :
        if  (dist_vect(Exe, Centres[c]) ) < mini :
            mini = dist_vect(Exe, Centres[c])
            index = c
    return index
def affecte_cluster(Base,Centres):
    U = {i: [] for i in range(len(Centres))}
    Base = np.asarray(Base)
    for i in range(len(Base)):
        U[plus_proche(Base[i], Centres)].append(i)
    return U

def nouveaux_centroides(Base,U):
    t = []
    Base = np.asarray(Base)
    for i in U.keys():
        t.append(centroide(Base[U[i]]))
    return np.asarray(t)
def inertie_globale(Base, U):
    inertie = 0
    Base = np.asarray(Base)
    for i in U.keys():
        inertie += inertie_cluster(Base[U[i]])
    return inertie

def kmoyennes(K, Base, epsilon, iter_max):
    Centroides = init_kmeans(K, Base)
    # Affectation des exemples à chaque cluster
    U = affecte_cluster(Base, Centroides)
    # Calcul de l'inertie globale
    inertie = inertie_globale(Base, U)
    print(inertie)
    for i in range(iter_max):
        Nouveaux_Centroides = nouveaux_centroides(Base, U)
        Centroides = Nouveaux_Centroides
        Nouveaux_U = affecte_cluster(Base, Centroides)
        Nouvelle_Inertie = inertie_globale(Base, Nouveaux_U)
        print("iteration",i+1," Inertie",Nouvelle_Inertie, "Différence", f'{abs(Nouvelle_Inertie-inertie):1.4f}')
        U = Nouveaux_U
        if abs(Nouvelle_Inertie - inertie) < epsilon:
            break
        inertie = Nouvelle_Inertie
    return Centroides, U